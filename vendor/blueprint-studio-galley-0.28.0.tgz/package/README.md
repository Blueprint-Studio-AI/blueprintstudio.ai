# Galley

Blog posts as MDX files that people and agents edit, using only the site's own components.
Built by Blueprint Studio; first used on arch.network.

Every post is one `.mdx` file in the site's repo: markdown plus the site's components.
Posts can't run code: no `import`, no `{expressions}`, no HTML tags, plain values for props,
and safe links only. Every save, check and render enforces that.

## What lives where

Three layers, each changed by different people in a different way:

| Layer | What's in it | Who changes it | How |
|---|---|---|---|
| **Galley** (this package, the same on every site) | The rules for a post (MDX with only the site's components, no code), checking and formatting, drafts, publishing, scheduling, preview links, history, the editor (dock, rail, panels), the agent tools, the CLI, and the shapes everything is defined in: `defineComponent`, `defineSection`, `defineMotion`, `defineTemplate`, `defineCard`, `defineLayout`, `setting()` and the cascade (blog → page → post → section → block) | Galley's maintainers | A Galley release; a site takes it by upgrading the package |
| **The site** (its repo, built per client) | Everything you see: the components, sections, cards and layouts, templates, entrances and scroll effects, design tokens, the front matter fields, the vocabulary (categories, topics…), the pages and their frame, the routes and CSS | The site's developers (for a Blueprint client, Blueprint) | A pull request on the site's repo. A client who needs something new asks for it in edit mode (a design request), and it ships as one |
| **The content** | Posts, the order and settings of a page's sections, the blog's settings, and every choice among what the site offers (a template, an entrance, a token, a layout) | The client's team in edit mode, and agents | Edit mode or the agent tools; every change is a draft until someone publishes it |

What a client can't do, by design: write code or raw HTML in a post, type a colour or size
that isn't a token, or use a component, section or template the site doesn't have. Each of
these is a request to the site's developers instead, so the site stays on brand and nothing
breaks. What Galley never does: style anything. A site upgrading Galley gets new editor
features and checks; its look doesn't change.

**This package** is the engine. It has no styling.
- The parser, validator, safe renderer and formatter.
- The Ghost importer and the `galley` CLI.
- The contracts for the base components (Image, YouTube, Tweet, LinkCard, Video, File,
  Callout): name, placement, and typed props.

**The site** owns everything visual:
- `galley.config.ts`: which components exist, where posts live, and the front matter
  schema.
- One file per component, e.g. `src/components/galley/callout.tsx`, holding the contract,
  examples and the styled React component. `galley add callout` copies in a starter, and
  from then on it's the site's code. Updates to this package never touch it.
- The theme: the site's own CSS and tokens.

```ts
// galley.config.ts
import { defineConfig } from "@blueprint-studio/galley";
import { callout } from "./src/components/galley/callout";
import { image } from "./src/components/galley/image";

export default defineConfig({
  postsDir: "content/blog/posts",
  componentsDir: "src/components/galley",
  components: [image, callout],
  frontmatter: PostFrontmatter, // a zod schema for the fields at the top of each post
});
```

A site component is a contract plus React:

```tsx
export const countUp = defineComponent({
  name: "CountUp",
  kind: "text",            // "flow" sits on its own line; "text" sits inside a sentence
  children: "none",        // "none" | "inline" (a caption) | "blocks" (paragraphs, lists…)
  description: "A number that counts up when it scrolls into view.",
  props: z.object({ to: z.number(), prefix: z.string().optional() }),
  examples: [{ props: { to: 2000000000, prefix: "$" } }],
  Component: ({ to, prefix }) => <span>{prefix}<CountUpNumber end={to} /></span>,
});
```

Interactive pieces, such as a video player, go in a separate `"use client"` file that the
component renders. The definition itself stays on the server.

## Using it

```ts
import { validatePost } from "@blueprint-studio/galley";
import { renderPost } from "@blueprint-studio/galley/render";

const result = validatePost(source, config); // { ok, frontmatter, errors: [{ line, column, message }] }
const body = renderPost(source, config);     // React, with only the site's components
```

The site styles plain Markdown with its own elements, and builds a table of contents from
`outline`, whose ids match the rendered headings:

```tsx
import { outline, renderPost } from "@blueprint-studio/galley/render";

const body = renderPost(source, config, {
  elements: { h2: (props) => <h2 className="text-2xl" {...props} />, a: ExternalLink },
});
const toc = outline(source).filter((h) => h.depth === 2); // [{ depth, text, id }]
```

```bash
galley check [files…] [--fix]   # posts and component examples; --fix rewrites the format
galley list                     # the site's components and their props
galley add [name…]              # copy starter components into the site
galley manifest [--out file]    # components and front matter as JSON Schema, for agents
galley preview <slug>|--components [--mobile]   # a screenshot of the running site
galley migrate settings|pages   # move settings and sections to where they're kept now
galley index                    # .galley/library.json: everything a post or page can use
galley publish-due [--now iso]  # publish the scheduled posts whose time has come (a cron runs it)
galley mcp                      # the agent tools, over stdio
```

`@blueprint-studio/galley/ghost` turns Ghost post HTML into Galley MDX, cleaning up what
pasting from Google Docs leaves behind.

### Pages built from sections

A page that isn't a post, such as the blog's home, is an ordered list of sections in a JSON
file. A section is a band of the page (a lead post with the latest beside it, a grid, a
sign-up) defined like a component: a contract with typed settings and defaults, plus the
site's React. Server components may be async and fetch the posts they show.

```tsx
import { defineSection } from "@blueprint-studio/galley/pages";

export const editorsPicks = defineSection({
  name: "EditorsPicks",
  label: "Editor's picks",
  description: "Up to three posts you choose, under a heading.",
  category: "Posts",
  props: z.object({ title: z.string(), posts: z.array(z.string()).max(3) }),
  defaults: { title: "Editor's picks", posts: [] },
  shows: ({ posts }) => posts, // sections below leave these out
  Component: async ({ title, posts, context }) => <Picks title={title} slugs={posts} edit={context.edit} />,
});

// galley.config.ts
export default defineConfig({ ..., sections: [editorsPicks, ...], pages: { "blog-home": "content/blog/home.json" } });
```

```json
{ "sections": [{ "id": "picks", "type": "EditorsPicks", "props": { "title": "Start here", "posts": ["welcome-to-arch"] } }] }
```

`renderPage(page, sections, { params, path, edit }, wrap?)` renders it (`wrap` puts
something around each section, such as the site's scroll animation); `validatePage` checks it
and `writePage` saves it only if it passes and hasn't changed since it was read. A section
marked `single` appears at most once. `galley check` checks every page in `pages`, and the
manifest lists the sections with their settings as JSON Schema.

### Lists of posts: one Collection

Every list of posts is one section built from the site's own pieces: cards
(`defineCard`, how one post is drawn) and layouts (`defineLayout`, how they're arranged: how
many it fits, which cards each place takes, any labels, whether it can list every post with
page numbers). `defineCollection({ layouts, cards, posts, fromAddress, text })` makes the
section. Its settings choose the posts (pinned first, categories, topics, featured, newest or
oldest, how many, leading with the newest featured post, leaving out ones shown above), the
layout, and a card for any place ("the last one large" is
`slots: [{ match: "last", card: "large" }]`). It's checked against the layout: no more posts
than it fits, only cards a place takes. In edit mode the Collection's view says what it
shows in a sentence, draws each layout with the real posts, and stops the count where the
layout does, saying why; clicking a post on the page shows its place's card.

Give the page editor `posts` actions (the draft store's `rows`, `trash` and `untrash`,
Galley's `duplicatePost`, `publishPost` and `unpublishPost`) and its rail gets All posts:
every post, drafts too, found by searching or by whether it's on the site, each with Open,
Duplicate, Publish or Unpublish, and Delete, which keeps the post in `.galley/trash/`
(git-ignore it) so the notice's Undo can bring it back.

A section that's been replaced names what replaces it (`migrate: { to, props(old) }`): pages
that still use it render through the replacement, the library stops offering it, and
`galley migrate pages` rewrites the page files once.

### The blog's settings

Defaults for every post and page, such as the template posts use when they don't choose one
or whether every block animates in, are the site's own zod object kept as JSON in its repo:

```ts
// galley.config.ts
settings: { file: "content/blog/settings.json", schema: BlogSettings },
```

`readSettings(cwd, settings)` (from `@blueprint-studio/galley/settings`) returns the values
with defaults filled in and a revision; `writeSettings` saves them only if they pass and
haven't changed since they were read. `galley check` checks the file, agents use
`read_settings` and `write_settings`, and edit mode shows them in the dock's Blog settings.

**Settings that cascade.** A setting a post or page can set for itself (the template, how
blocks come into view) is declared once with `setting()`: the levels it can be set at and
where each keeps it (a dotted path in the settings file, a post's front matter, a page's or
section's own `settings`).

```ts
setting({ key: "motion.entrance", label: "Entrance", schema: z.enum(["none", "fade-up"]), default: "none",
          levels: ["blog", "page", "post"], at: { blog: "motion.entrance", page: "settings.entrance", post: "entrance" },
          play: "entrance" })
```

List them in `settings.cascade`. `resolveSetting(def, { blog, page, post })` says what one
comes to and where it came from; the site renders with that. Edit mode shows each where it's
set ("From blog · Article", "Set here", "Default") with a way back to the level above, and
plays an entrance (`play: "entrance"`) when it changes. A setting that moved can name its
old places (`from`), and `galley migrate settings` moves the file's values over, once.

### Drafts and publishing

Nothing edit mode or an agent changes reaches readers until it's published. Set
`publish: { draftField: "draft", dateField: "publishedAt" }` in the config and save posts
through a `DraftPostStore` (from `@blueprint-studio/galley/drafts`): a post that's on the site
gets its changes in `.galley/drafts/` (git-ignore it), and one that isn't (`draft: true`) is
edited in place. `publishPost` and `unpublishPost` (from `/editor`) put a post on the site,
dated then if it's the first time, or take it off, and note both in its history; a post that
wouldn't pass as published stays a draft and says why. Pages and the blog's settings work
the same way with `openPage`/`savePageDraft`/`publishPage` and
`openSettings`/`saveSettingsDraft`/`publishSettings`. Give the editors `publish`, `unpublish`
and `discard` actions and they get Publish in the rail. The site's public pages read only the
published files, and turn drafts away.

**Scheduling.** Add `scheduleField: "publishAt"` to `publish` (and `publishAt` to the front
matter schema, as an optional date and time with its offset), and give the editor `schedule`
and `unschedule` actions (`schedulePost`, `unschedulePost`). A post that isn't on the site
gets Schedule… beside Publish: a date and time in the site's timezone (`publish.timezone`,
IANA; the person's own when unset). The post stays a draft, so it's in no list, feed or
sitemap and its page is "not found", until `galley publish-due` runs at or after that time.
That publishes it, dated the time it was scheduled for, and drops `publishAt`. Run it from a
cron that commits what changed. On GitHub:

```yaml
on: { schedule: [{ cron: "7 * * * *" }], workflow_dispatch: {} }
permissions: { contents: write }
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      # …set up pnpm and node, pnpm install --frozen-lockfile…
      - run: pnpm galley publish-due
      - run: |
          git add content && git diff --cached --quiet && exit 0
          git -c user.name="github-actions[bot]" -c user.email="41898282+github-actions[bot]@users.noreply.github.com" commit -m "Publish scheduled posts"
          git push
```

Each run costs at least a minute of Actions time. Hourly is 720 minutes a month at most; Arch's
workflow stops before installing anything when no post has `publishAt`.

**Preview links.** Add `previewUrl: "/blog/{slug}/preview?t={token}"` to `publish`, a route
there, and the `previewLinks`, `createPreviewLink` and `revokePreviewLink` actions (from
`@blueprint-studio/galley/preview-links`). Publish then has Copy preview link for anything
that isn't on the site as it is: a link that shows the draft to someone who isn't editing,
for a week or until it's revoked. The route opens the token with `openPreviewLink` (null means
"not found"), reads the post through the `DraftPostStore`, renders it like the public page with
`<PreviewBanner>`, and sets `robots: { index: false }`. Tokens are signed with
`GALLEY_PREVIEW_SECRET`, or a secret kept in `.galley/preview-secret`; the links that work are
in `.galley/previews.json`. Git-ignore both. Opening a link never writes anything, so a
deployment without them simply says "not found".

### Motion

A site's animations are its own components. An entrance (something coming into view as the
reader scrolls to it) is declared with `defineMotion`: its name, a label, what it does, the
component, how edit mode replays it (`play`, Web Animations keyframes that match the
component) and what it does under reduced motion. It wraps blocks, so a post keeps what
animates in its MDX (`<Reveal>…</Reveal>`); register `still` too, so a block can keep still
(`<Still>`) whatever its post does. An entrance setting's choices are
`entranceChoice([fadeUp, iris])`: "none", then each by name. Edit mode shows them as tiles
that play, at every level the setting cascades to (the blog, a page or post, a section, a
block), and plays the choice on the page. The site renders a post with
`renderPost(source, config, { motion: entrance })` and a page's sections with
`renderPage(…, (node, section) => inEntrance(config, entranceOf(section), node))`.

A scroll effect is `defineMotion({ kind: "scroll", … })`: it follows the reader's scrolling
while the block passes through the view (a parallax), its `play` keyframes running from
entering the view to leaving it. A block has an entrance or a scroll effect; edit mode
offers scroll effects on a block with a slider that runs it through the effect without
scrolling, and shows the block's entrance disabled, saying why. CSS scroll-driven
animations (`animation-timeline: view()`) are the smooth way for a site to build one.

A cascading setting that has no effect somewhere is shown there disabled with the reason
(`CascadeField`'s `inactive`), never saved to do nothing.

Only real choices: an option marked `status: "planned"` anywhere (front matter, settings,
sections) makes `defineConfig` throw. A component can carry a `label` for how the editor
names it ("Picture and text").

### The design system

A site's colours, fonts and type styles are tokens in a W3C Design Tokens (DTCG) file beside
its CSS, each naming the CSS variable it is (`$extensions.galley.cssVar`), with a label
("Brand orange") and what it's for (`roles`). `fromDtcg(json)` reads them; pass them as the
config's `design: { tokens }`. A component or section setting that takes one is
`tokenChoice(tokens, { kind: "color", roles: ["accent"] })`: it stores the token's name, a
raw colour fails the check, and edit mode shows the choices as named swatches in a Style
group (type styles as samples in their real font). There's no colour picker and no hex
field anywhere. Blog settings › Design shows every token with how many posts use it
(`tokenUsage`) and a way to ask for a change; agents use `list_tokens`. Text blocks' styles
are drawn in the site's own type.

### The library

`galley index` (and edit mode, fresh each time) builds one list of everything a post or
page can use (`@blueprint-studio/galley/library`): the site's blocks, entrances, sections
and templates, and the pictures, video, Lottie animations (JSON) and files in its media
folder, named from the alt text posts give them. Each thing someone built carries the pull
request that added it (from the commit that added its file), and is shown as New for two
weeks, so the design agent's merged work appears without anyone registering it. Give the
editors a `siteLibrary` action (`buildLibrary(config, cwd)`) and the post editor's Add
becomes the Library: Blocks, Motion and Media in one view with one search, video and Lottie
playing while pointed at. Agents use `search_library`. Lottie is a base contract with a
starter (`galley add lottie`, which uses lottie-web's light player) that stays on its first
frame for readers who ask for less motion.

### Templates and design requests

A site's templates are `defineTemplate({ name, label, useWhen, for: "post", preview })`, the
preview a screenshot of a real post (`galley check` checks it's in `public/`), listed in
the config's `templates`; the site keeps one layout per name. `templateChoice(templates)`
is the template setting's choices. One that's wanted but not built is a design request
(`@blueprint-studio/galley/requests`): edit mode's "Ask for a new template" card writes one
to `.galley/requests/`, agents use `request_design`, and the design agent follows them with
`list_requests` and `update_request` (its pull request, then "shipped" with the name it
shipped as). Pass the editors `design={{ list, ask }}`; what's asked for is listed where
it's chosen with its status, and the person who asked is told when it's ready.

### Edit mode

`@blueprint-studio/galley/editor-ui` is edit mode for Next.js sites: the site's own post
page, editable in place. Wrap the post layout in `<EditSession>` (with the site's server
actions for saving, rendering components, the Blueprint Studio library and history) and
put `EditableText`, `EditableImage`, `EditableTerm`, `EditableAuthors` and `EditableBody`
where the title, cover, category, byline and body go. A page built from sections uses
`<PageEditor>`; a section renders its editable words with `SectionText` from
`@blueprint-studio/galley/section-text`. It needs `@tiptap/*` 3 alongside React 19.

Everything edit mode opens is one dock down the right edge: the rail of controls, and beside
it whatever is open (adding a block or section, drawn by the site itself; a selected block's
or section's settings; the picture chooser; details; comments; history; Blog settings). It
changes size to fit what it shows and slides the next view in from its button's side, like
a navigation menu. On the page, what you point at and select is drawn with construction
lines on its real box, and the page builds in from its skeleton when edit mode loads. Pass
`settings` to both editors. Sites whose header is taller or shorter than 92px
set `--gx-top` to where the dock starts.

**⌘K and ?.** ⌘K (Ctrl+K elsewhere) opens a search in the dock over everything edit mode can
do. That covers:
- every button on the rail;
- every shortcut;
- the blocks or sections that can be added;
- the sections already on a page;
- every setting, which opens the view that has it with the field focused;
- the other posts, to go to one. Give the post editor `postRows` (`DraftPostStore.rows`) for this; the page editor uses its All posts action.

`?` lists the shortcuts. Each editor's shortcuts are one table: they're the keys that work, what `?`
lists, and what ⌘K shows beside each action, so the three can't disagree. A post has ⌘Z,
⇧⌘Z, `/` for blocks, ⌥⌘M to comment, ⌘S and ⌘↵ to publish. A page also has ⌥↑ and ⌥↓ to
move the selected section, ⌘D to duplicate it and ⌫ to delete it. `e2e/keys.spec.ts` presses
every shortcut `?` lists, and fails on one it has no check for.

**Preview.** Give the post editor `readerUrl`, and the rail gets Preview (and ⇧⌘P). It shows
the post as readers will see it, over edit mode, at desktop width or in a 375 px phone frame.
Esc goes back to editing where you were. It's the site's own preview page for the draft,
opened on a quiet link that lasts an hour and isn't listed with shared links:
`createPreviewLink(cwd, key, { days: 1 / 24, quiet: true })`. The page leaves out
`<PreviewBanner>` when `opened.link.quiet` is set.

### A post as an email

`renderEmail(source, config, options)` (from `@blueprint-studio/galley/email`) turns a post
into an email for a newsletter: `{ html, text }`. It's the same post through a second
renderer made for mail apps, the way Ghost does it:
- tables and inline styles;
- full URLs against `siteUrl`;
- no scripts, video or iframes;
- a plain-text version;
- a hidden preview line;
- a "Read it on the site" button;
- the footer the law asks for: why the reader is getting it, `unsubscribeUrl` and the sender's postal address.

A component reads in email through its `Email` form (synchronous; it gets its props plus
`email: { postUrl, absolute, theme }`). One without falls back to Galley's:
- Image stays a picture with its caption;
- YouTube becomes its thumbnail linking to the video;
- Video becomes its poster linking to the post;
- Tweet, LinkCard and File become cards;
- Callout becomes a tinted box;
- Lottie becomes a card pointing to the post;
- an entrance or scroll effect is just what it moves;
- a counting number is its final number;
- any other block is a card saying it's in the post.

`theme` sets the colours and fonts. Before sending, `checkEmailAssets(source, { siteUrl })`
finds the widest thumbnail each video has and the link-card pictures that don't load, and
`assets` passes that in: an email can't fall back to another picture the way a page can.

### Newsletters

`newsletters({ newsletters, provider, secret, siteUrl, site, from })` (from
`@blueprint-studio/galley/newsletter`) is everything a site's sign-up form and emails
need. The provider the site picks keeps the readers; Galley never stores an address.
- **`subscribe({ email, newsletters?, honeypot? })`** sends a confirmation email. Nobody is
  added until they click it (double opt-in), and a filled-in honeypot field looks like success
  and sends nothing.
- **`confirm(token)`** subscribes the reader to what they chose (the `default` newsletters if
  nothing), with when and how they consented.
- **`unsubscribe(token)`** is one-click unsubscribe, from one newsletter or all. Serve it as a
  POST that needs no cookie (mail apps call it, RFC 8058) and as the footer's link.
- **`preferences(token)` and `setPreferences(token, ids)`** are the page where a reader keeps
  the newsletters they want.
- **`headers(email, newsletter)`** gives every email `List-Unsubscribe` and
  `List-Unsubscribe-Post`, so mail apps show their own unsubscribe button.
- **`unsubscribeUrl` and `preferencesUrl`** are the footer's links.

Links are encrypted and signed with `secret` (`GALLEY_NEWSLETTER_SECRET`, 32 characters or
more; there's no default). No address ever shows in a URL, and nobody can change one.

There are three providers:
- **`resendProvider({ apiKey, segments })`**: Resend, where each newsletter is a segment.
  Every reader gets their own email, sent a hundred at a time, so each carries its own
  unsubscribe link. Fast enough to send from a request; priced by the month.
- **`sesProvider({ region, accessKeyId, secretAccessKey, contactList, topics, perSecond, sent })`**:
  Amazon SES, where readers are contacts on one contact list and each newsletter is a topic.
  It costs about $0.10 per 1,000 emails with no monthly fee, but it's slower. SES sends at the
  account's own rate (`perSecond`), and every other call is limited to one a second. A big send
  takes minutes, so run it as a background job. SES has no idempotency key, so give it `sent`
  (somewhere to note each email's `key`) and a retried send skips what already went.
- **`outboxProvider(dir)`**: for development and tests. It writes every email to a folder;
  never use it in production.

Another provider (Listmonk, say) implements `NewsletterProvider`.

**Emailing a post.**
1. Render it once with `renderEmail`, with `unsubscribeUrl: READER_LINKS.unsubscribe` and
   `preferencesUrl: READER_LINKS.preferences`.
2. Call `send(issue, newsletter, { key })`. Each reader gets their own copy, with their
   own links and the one-click headers, a hundred at a time.

Sending again with the same `key` (a retry) sends nobody twice. `sendTest(issue, to)` sends
one copy marked "[Test]". `sendsLog(dir)` keeps what each post went to, with counts and no
addresses.

Give the post editor a `newsletter` action, `{ info, test, send }`, and Publish gets "Email it to
readers": the newsletters with their reader counts, a test send, and a confirmation that says
how many people it goes to. Publishing a draft that way publishes it, then emails it.

### Version history

`recordSave(cwd, "posts/<slug>", { before, after, author, note? })` (from `@blueprint-studio/galley/editor`)
notes each save edit mode makes; a note ("Published") marks a moment of its own. A stretch of saves by one person within ten minutes is one
version, the state before the first edit is kept, and changes made outside edit mode show
up as their own version. `listVersions` and `readVersion` read them back for a history
panel. It lives in `.galley/history/`, which sites should git-ignore: the repo's own history
is the record that ships.

## For agents

`galley mcp` serves Galley's tools over stdio to agents working in the site's repo. Register
it in `.mcp.json` as `{"command": "./node_modules/.bin/galley", "args": ["mcp"]}`. Calling it
through `pnpm galley` would print pnpm's banner onto stdout and break the protocol. The tools:

- `list_posts`, `read_post`: posts with line numbers and a revision.
- `edit_post`: find-and-replace on exact text, refused if the post changed since it was read.
- `write_post`: create or replace a whole post.
- `check_post`: check MDX without saving.
- `list_components`: what each component is for, its props and an example.
- `import_media`: bring an https image (e.g. from Blueprint's Asset Generator) into the site.
- `list_sections`, `read_page`, `write_page`: pages built from sections, for sites that have
  them. A page is written whole, with the revision it was read at.
- `read_settings`, `write_settings`: the blog's settings, for sites that have them, written
  whole with the revision they were read at.
- `list_drafts`, `publish`, `unpublish_post`: every write is a draft until it's published,
  as in edit mode. `publish` with `at` schedules a post, on sites with `publish.scheduleField`;
  `list_drafts` lists what's scheduled.
- `create_preview_link`: a link a person can open to see a post's draft, on sites with
  `publish.previewUrl`.
- `preview`: a post or the component gallery as screen-sized screenshots. Needs
  `playwright-core` and a `preview` block in the config, and works best against `pnpm dev`,
  where edits show up immediately.

Every save is checked first. A failed check returns line-numbered errors and nothing is
written. The same operations live in `@blueprint-studio/galley/ops` for other surfaces, over
any `PostStore`.

## For hosted tools

Blueprint's MCP works on a client's repo through GitHub, not the disk:

- `configFromManifest(manifest)` rebuilds a site's rules from its `.galley/manifest.json`.
  Posts are checked exactly as the site would check them, without running its code.
- `GitHubPostStore` (`@blueprint-studio/galley/github`) reads published posts from the base
  branch. Every write goes to that post's draft branch (`galley/<slug>`), with one open pull
  request, so a person merges to publish. Agents never write to the base branch. Hosted
  Galley uses `GitHubContentStore` instead (next section).
- `githubAppTokens` signs the GitHub App's JWT and caches each installation's token.
- `prepareMedia` (`@blueprint-studio/galley/media`) downloads and optimises an image through the
  host's own `fetch`, so the host decides what may be fetched. `putFile` then adds it to the
  draft branch.

## Hosted: editing on the live site

Deployed, a site's editors sign in through hosted Galley, and their changes go to the site's
repository through it. `@blueprint-studio/galley/hosted` is the site's side, framework-free:
- **`hostedFromEnv(origin)`** reads `GALLEY_URL`, `GALLEY_SITE_ID`, `GALLEY_CLIENT_ID` and
  `GALLEY_CLIENT_SECRET` (Galley's admin page shows them once, when the site is added). It's
  null where the site isn't hosted, so edit mode works on the files on a laptop.
- **`beginSignIn` and `finishSignIn`** are OAuth with PKCE through Galley. They check it's the
  attempt this browser began, and they only send the person somewhere on the site. The
  tokens are sealed (AES-GCM, keyed by the client secret) in an httpOnly cookie on the site's
  own domain. `readSession`, `needsRefresh`, `refreshSession` and `signOut` do the rest.
- **`hostedContent(config, accessToken)`** is the content API as one editor: read, save
  (from a base revision, so crossing someone else's save is a `CONFLICT`), publish, schedule,
  history, trash and preview links.
- **`HostedPostStore`** is that as an `EditorPostStore`, which `DraftPostStore` also is, so a
  site's edit actions take either. `hostedPreview(config, token)` is what a preview link opens.

A site adds four routes (`/api/galley/sign-in`, `/callback`, `/refresh` and `/sign-out`) and
asks who's editing in its edit pages and actions. Arch's `src/app/blog/edit/editing.ts` is
the worked example. The service itself is `cloud/`.

## Hosted: the GitHub store

Hosted Galley edits a site's posts, pages and settings in the site's own GitHub repo,
through the Galley GitHub App. `GitHubContentStore` (`@blueprint-studio/galley/github`) is
that store:

```ts
import { GitHubContentStore, installationToken } from "@blueprint-studio/galley/github";

// Refuses to start without the App's id and a key that can sign.
const token = installationToken({ appId: process.env.GALLEY_GITHUB_APP_ID!, privateKey: process.env.GALLEY_GITHUB_APP_KEY!, installationId });
const store = new GitHubContentStore(
  { owner: "Arch-Network", repo: "arch-site", base: "main", token },
  {
    files: { postsDir: "content/blog", pages: { "blog-home": "content/blog/home.json" }, settings: "content/blog/settings.json", media: "public/media" },
    rules: { fields: { draftField: "draft", dateField: "publishedAt", scheduleField: "publishAt" }, check: config },
  },
);
```

A host that can't run the site's code sets the store up from the manifest the site commits
(`galley manifest` writes `.galley/manifest.json`; the site's CI keeps it current). It
carries where the posts, pages, settings and media are, the publish fields, and the
components and front matter posts are checked against:

```ts
const { store, manifest, config } = await GitHubContentStore.fromManifest({ owner, repo, base, token });
```

- What's on `base` is published. A document's draft is a branch of its own
  (`galley/posts-<slug>`, `galley/pages-<name>`, `galley/settings`), made from `base` on its
  first save, so `base` only changes when someone publishes.
- `read(key, "published" | "draft")` gives `{ text, revision }`, and `state(key)` the same
  states as local edit mode.
- `saveDraft(key, text, { base, author, client })` is one `createCommitOnBranch` that says
  which head it expects. `base` is the revision the editor started from: if the draft has
  moved since, it's a `CONFLICT`, never an overwrite. Saving exactly what's published deletes
  the branch.
- `publish(key, { author, files })` is one commit on `base` (the document, and any images,
  which must be in `media`), then the branch goes. Posts follow the local rules: dated the
  first time, keeping their date after `unpublish`, and losing the schedule field. There's
  also `unpublish`, `schedule`, `unschedule`, `publishDue` (for a cron), `discard`,
  `trash`/`untrash` (a `galley-trash/` branch keeps the post and its draft), `listDrafts`,
  `history` (the commits on `base` and on the draft branch) and `readVersion`.
- `postStore({ author, client })` is a `PostStore`, so the `ops` functions, and agents'
  tools, work over the repo.
- Commits carry `Galley-User`, `Galley-Client` and `Galley-Note` trailers.
- A repo's writes go one at a time, at least a second apart, within the process. When GitHub
  asks Galley to slow down (a 403 secondary rate limit, a 429), it waits as long as
  `Retry-After` says and tries again, up to `pace.retries` times and `pace.maxWait` long.
- Galley's own rules (a post that can't go on the site yet) answer `{ ok: false, error }`,
  as `DraftPostStore` does. GitHub's failures throw `GalleyStoreError { code, message,
  safeToRetry }`: `CONFLICT`, `NOT_FOUND`, `RATE_LIMITED`, `NO_ACCESS`, `TOO_LARGE` or
  `GITHUB_DOWN`. `message` is for editors; GitHub's status and words are in `cause`, for logs.
- `test/fake-github.ts` is an in-memory GitHub to test against. It refuses a stale
  `expectedHeadOid` as GitHub does, and rate-limits or fails on demand.

## Developing

```bash
pnpm install
pnpm test        # safety rules, Ghost import, manifest round trip, agent ops, the GitHub store
pnpm typecheck   # engine and starters
pnpm build
```

CONTRIBUTING.md has the rules: the layers, the content format, adding other frameworks
(including non-React sites), edit mode's design and motion rules, and frame-checking
motion with `scripts/motion/`.

Sites install a packed release. `pnpm pack:vendor` writes the `.tgz` to
`../galley-releases/`. The site copies it into its `vendor/` folder and depends on
`file:./vendor/blueprint-studio-galley-<version>.tgz`. That way a client's site builds
without Blueprint's credentials.
