# Galley

Blog posts as MDX files that people and agents edit, using only the site's own components.
Built by Blueprint Studio; first used on arch.network.

Every post is one `.mdx` file in the site's repo: markdown plus the site's components.
Posts can't run code: no `import`, no `{expressions}`, no HTML tags, plain values for props,
and safe links only. Every save, check and render enforces that.

## What lives where

**This package** is the engine. It has no styling.
- The parser, validator, safe renderer and formatter.
- The Ghost importer and the `galley` CLI.
- The contracts for the base components (Image, YouTube, Tweet, LinkCard, Video, File,
  Callout): name, placement, and typed props.

**The site** owns everything visual:
- `galley.config.ts`: which components exist, where posts live, and the front matter
  schema.
- One file per component, e.g. `src/components/galley/callout.tsx`, holding the contract,
  examples and the styled React component. `galley add callout` copies in a starter, and
  from then on it's the site's code. Updates to this package never touch it.
- The theme: the site's own CSS and tokens.

```ts
// galley.config.ts
import { defineConfig } from "@blueprint-studio/galley";
import { callout } from "./src/components/galley/callout";
import { image } from "./src/components/galley/image";

export default defineConfig({
  postsDir: "content/blog/posts",
  componentsDir: "src/components/galley",
  components: [image, callout],
  frontmatter: PostFrontmatter, // a zod schema for the fields at the top of each post
});
```

A site component is a contract plus React:

```tsx
export const countUp = defineComponent({
  name: "CountUp",
  kind: "text",            // "flow" sits on its own line; "text" sits inside a sentence
  children: "none",        // "none" | "inline" (a caption) | "blocks" (paragraphs, lists…)
  description: "A number that counts up when it scrolls into view.",
  props: z.object({ to: z.number(), prefix: z.string().optional() }),
  examples: [{ props: { to: 2000000000, prefix: "$" } }],
  Component: ({ to, prefix }) => <span>{prefix}<CountUpNumber end={to} /></span>,
});
```

Interactive pieces, such as a video player, go in a separate `"use client"` file that the
component renders. The definition itself stays on the server.

## Using it

```ts
import { validatePost } from "@blueprint-studio/galley";
import { renderPost } from "@blueprint-studio/galley/render";

const result = validatePost(source, config); // { ok, frontmatter, errors: [{ line, column, message }] }
const body = renderPost(source, config);     // React, with only the site's components
```

The site styles plain Markdown with its own elements, and builds a table of contents from
`outline`, whose ids match the rendered headings:

```tsx
import { outline, renderPost } from "@blueprint-studio/galley/render";

const body = renderPost(source, config, {
  elements: { h2: (props) => <h2 className="text-2xl" {...props} />, a: ExternalLink },
});
const toc = outline(source).filter((h) => h.depth === 2); // [{ depth, text, id }]
```

```bash
galley check [files…] [--fix]   # posts and component examples; --fix rewrites the format
galley list                     # the site's components and their props
galley add [name…]              # copy starter components into the site
galley manifest [--out file]    # components and front matter as JSON Schema, for agents
galley preview <slug>|--components [--mobile]   # a screenshot of the running site
galley mcp                      # the agent tools, over stdio
```

`@blueprint-studio/galley/ghost` turns Ghost post HTML into Galley MDX, cleaning up what
pasting from Google Docs leaves behind.

## For agents

`galley mcp` serves Galley's tools over stdio to agents working in the site's repo. Register
it in `.mcp.json` as `{"command": "./node_modules/.bin/galley", "args": ["mcp"]}`. Calling it
through `pnpm galley` would print pnpm's banner onto stdout and break the protocol. The tools:

- `list_posts`, `read_post`: posts with line numbers and a revision.
- `edit_post`: find-and-replace on exact text, refused if the post changed since it was read.
- `write_post`: create or replace a whole post.
- `check_post`: check MDX without saving.
- `list_components`: what each component is for, its props and an example.
- `import_media`: bring an https image (e.g. from Blueprint's Asset Generator) into the site.
- `preview`: a post or the component gallery as screen-sized screenshots. Needs
  `playwright-core` and a `preview` block in the config, and works best against `pnpm dev`,
  where edits show up immediately.

Every save is checked first. A failed check returns line-numbered errors and nothing is
written. The same operations live in `@blueprint-studio/galley/ops` for other surfaces, over
any `PostStore`.

## For hosted tools

Blueprint's MCP works on a client's repo through GitHub, not the disk:

- `configFromManifest(manifest)` rebuilds a site's rules from its `.galley/manifest.json`.
  Posts are checked exactly as the site would check them, without running its code.
- `GitHubPostStore` (`@blueprint-studio/galley/github`) reads published posts from the base
  branch. Every write goes to that post's draft branch (`galley/<slug>`), with one open pull
  request, so a person merges to publish. Agents never write to the base branch.
- `githubAppTokens` signs the GitHub App's JWT and caches each installation's token.
- `prepareMedia` (`@blueprint-studio/galley/media`) downloads and optimises an image through the
  host's own `fetch`, so the host decides what may be fetched. `putFile` then adds it to the
  draft branch.

## Developing

```bash
pnpm install
pnpm test        # safety rules, Ghost import, manifest round trip, agent ops, GitHub drafts
pnpm typecheck   # engine and starters
pnpm build
```

Sites install a packed release. `pnpm pack:vendor` writes the `.tgz` to
`../galley-releases/`. The site copies it into its `vendor/` folder and depends on
`file:./vendor/blueprint-studio-galley-<version>.tgz`. That way a client's site builds
without Blueprint's credentials.
