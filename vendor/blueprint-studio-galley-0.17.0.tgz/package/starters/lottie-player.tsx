"use client";

import { useEffect, useRef, useState } from "react";

// Plays a Lottie animation with lottie-web's light player, loaded only when one is on the
// page. It starts when it comes into view; for readers who ask for less motion it stays on
// its first frame. `data-lottie` says where it's got to (loading, playing, still, failed).

type Animation = { play(): void; destroy(): void; goToAndStop(frame: number, isFrame: boolean): void };

export function LottiePlayer({ src, alt, loop, width, height }: { src: string; alt: string; loop?: boolean; width?: number; height?: number }) {
  const box = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<"loading" | "playing" | "still" | "failed">("loading");
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    let live = true;
    let animation: Animation | null = null;
    let seen: IntersectionObserver | null = null;
    const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
    (async () => {
      const [{ default: lottie }, data] = await Promise.all([import("lottie-web/build/player/lottie_light"), fetch(src).then((r) => r.json() as Promise<unknown>)]);
      if (!live) return;
      animation = lottie.loadAnimation({ container: el, renderer: "svg", loop: Boolean(loop), autoplay: false, animationData: data });
      if (still) {
        animation.goToAndStop(0, true);
        setState("still");
        return;
      }
      seen = new IntersectionObserver(([entry]) => {
        if (!entry.isIntersecting) return;
        animation?.play();
        setState("playing");
        seen?.disconnect();
      });
      seen.observe(el);
    })().catch(() => live && setState("failed"));
    return () => {
      live = false;
      seen?.disconnect();
      animation?.destroy();
    };
  }, [src, loop]);
  return <div ref={box} role="img" aria-label={alt} data-lottie={state} style={{ aspectRatio: width && height ? `${width} / ${height}` : undefined }} />;
}
