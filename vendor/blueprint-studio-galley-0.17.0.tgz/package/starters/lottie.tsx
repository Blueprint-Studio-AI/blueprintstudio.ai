import { defineComponent } from "@blueprint-studio/galley";
import { Lottie } from "@blueprint-studio/galley/contracts";
import { LottiePlayer } from "./lottie-player";

// Starter from `galley add lottie`. This file is the site's now: restyle it freely. The
// player (lottie-web's light build, `pnpm add lottie-web`) loads only on pages with one.
// Point the example at a Lottie JSON file in the site's media folder.

export const lottie = defineComponent({
  ...Lottie,
  examples: [{ title: "A Lottie animation", props: { src: "/media/lottie/example.json", alt: "A short animation", loop: true } }],
  Component: (props) => (
    <figure className="galley-lottie">
      <LottiePlayer {...props} />
    </figure>
  ),
});
