# Galley

Blog posts as MDX files that people and agents edit, using only the site's own components.
Built by Blueprint Studio; first used on arch.network.

Every post is one `.mdx` file in the site's repo: markdown plus the site's components.
Posts can't run code: no `import`, no `{expressions}`, no HTML tags, plain values for props,
and safe links only. Every save, check and render enforces that.

## What lives where

**This package** is the engine. It has no styling.
- The parser, validator, safe renderer and formatter.
- The Ghost importer and the `galley` CLI.
- The contracts for the base components (Image, YouTube, Tweet, LinkCard, Video, File,
  Callout): name, placement, and typed props.

**The site** owns everything visual:
- `galley.config.ts`: which components exist, where posts live, and the front matter
  schema.
- One file per component, e.g. `src/components/galley/callout.tsx`, holding the contract,
  examples and the styled React component. `galley add callout` copies in a starter, and
  from then on it's the site's code. Updates to this package never touch it.
- The theme: the site's own CSS and tokens.

```ts
// galley.config.ts
import { defineConfig } from "@blueprint-studio/galley";
import { callout } from "./src/components/galley/callout";
import { image } from "./src/components/galley/image";

export default defineConfig({
  postsDir: "content/blog/posts",
  componentsDir: "src/components/galley",
  components: [image, callout],
  frontmatter: PostFrontmatter, // a zod schema for the fields at the top of each post
});
```

A site component is a contract plus React:

```tsx
export const countUp = defineComponent({
  name: "CountUp",
  kind: "text",            // "flow" sits on its own line; "text" sits inside a sentence
  children: "none",        // "none" | "inline" (a caption) | "blocks" (paragraphs, lists…)
  description: "A number that counts up when it scrolls into view.",
  props: z.object({ to: z.number(), prefix: z.string().optional() }),
  examples: [{ props: { to: 2000000000, prefix: "$" } }],
  Component: ({ to, prefix }) => <span>{prefix}<CountUpNumber end={to} /></span>,
});
```

Interactive pieces, such as a video player, go in a separate `"use client"` file that the
component renders. The definition itself stays on the server.

## Using it

```ts
import { validatePost } from "@blueprint-studio/galley";
import { renderPost } from "@blueprint-studio/galley/render";

const result = validatePost(source, config); // { ok, frontmatter, errors: [{ line, column, message }] }
const body = renderPost(source, config);     // React, with only the site's components
```

The site styles plain Markdown with its own elements, and builds a table of contents from
`outline`, whose ids match the rendered headings:

```tsx
import { outline, renderPost } from "@blueprint-studio/galley/render";

const body = renderPost(source, config, {
  elements: { h2: (props) => <h2 className="text-2xl" {...props} />, a: ExternalLink },
});
const toc = outline(source).filter((h) => h.depth === 2); // [{ depth, text, id }]
```

```bash
galley check [files…] [--fix]   # posts and component examples; --fix rewrites the format
galley list                     # the site's components and their props
galley add [name…]              # copy starter components into the site
galley manifest [--out file]    # components and front matter as JSON Schema, for agents
galley preview <slug>|--components [--mobile]   # a screenshot of the running site
galley mcp                      # the agent tools, over stdio
```

`@blueprint-studio/galley/ghost` turns Ghost post HTML into Galley MDX, cleaning up what
pasting from Google Docs leaves behind.

### Pages built from sections

A page that isn't a post, such as the blog's home, is an ordered list of sections in a JSON
file. A section is a band of the page (a lead post with the latest beside it, a grid, a
sign-up) defined like a component: a contract with typed settings and defaults, plus the
site's React. Server components may be async and fetch the posts they show.

```tsx
import { defineSection } from "@blueprint-studio/galley/pages";

export const editorsPicks = defineSection({
  name: "EditorsPicks",
  label: "Editor's picks",
  description: "Up to three posts you choose, under a heading.",
  category: "Posts",
  props: z.object({ title: z.string(), posts: z.array(z.string()).max(3) }),
  defaults: { title: "Editor's picks", posts: [] },
  shows: ({ posts }) => posts, // sections below leave these out
  Component: async ({ title, posts, context }) => <Picks title={title} slugs={posts} edit={context.edit} />,
});

// galley.config.ts
export default defineConfig({ ..., sections: [editorsPicks, ...], pages: { "blog-home": "content/blog/home.json" } });
```

```json
{ "sections": [{ "id": "picks", "type": "EditorsPicks", "props": { "title": "Start here", "posts": ["welcome-to-arch"] } }] }
```

`renderPage(page, sections, { params, path, edit }, wrap?)` renders it (`wrap` puts
something around each section, such as the site's scroll animation); `validatePage` checks it
and `writePage` saves it only if it passes and hasn't changed since it was read. A section
marked `single` appears at most once. `galley check` checks every page in `pages`, and the
manifest lists the sections with their settings as JSON Schema.

### The blog's settings

Defaults for every post and page, such as the template posts use when they don't choose one
or whether every block animates in, are the site's own zod object kept as JSON in its repo:

```ts
// galley.config.ts
settings: { file: "content/blog/settings.json", schema: BlogSettings },
```

`readSettings(cwd, settings)` (from `@blueprint-studio/galley/settings`) returns the values
with defaults filled in and a revision; `writeSettings` saves them only if they pass and
haven't changed since they were read. `galley check` checks the file, agents use
`read_settings` and `write_settings`, and edit mode shows them in the dock's Blog settings.

**Settings that cascade.** A setting a post or page can set for itself (the template, how
blocks come into view) is declared once with `setting()`: the levels it can be set at and
where each keeps it (a dotted path in the settings file, a post's front matter, a page's or
section's own `settings`).

```ts
setting({ key: "motion.entrance", label: "Entrance", schema: z.enum(["none", "fade-up"]), default: "none",
          levels: ["blog", "page", "post"], at: { blog: "motion.entrance", page: "settings.entrance", post: "entrance" },
          play: "entrance" })
```

List them in `settings.cascade`. `resolveSetting(def, { blog, page, post })` says what one
comes to and where it came from; the site renders with that. Edit mode shows each where it's
set ("From blog · Article", "Set here", "Default") with a way back to the level above, and
plays an entrance (`play: "entrance"`) when it changes. A setting that moved can name its
old places (`from`), and `galley migrate settings` moves the file's values over, once.

### Drafts and publishing

Nothing edit mode or an agent changes reaches readers until it's published. Set
`publish: { draftField: "draft", dateField: "publishedAt" }` in the config and save posts
through a `DraftPostStore` (from `@blueprint-studio/galley/drafts`): a post that's on the site
gets its changes in `.galley/drafts/` (git-ignore it), and one that isn't (`draft: true`) is
edited in place. `publishPost` and `unpublishPost` (from `/editor`) put a post on the site,
dated then if it's the first time, or take it off, and note both in its history; a post that
wouldn't pass as published stays a draft and says why. Pages and the blog's settings work
the same way with `openPage`/`savePageDraft`/`publishPage` and
`openSettings`/`saveSettingsDraft`/`publishSettings`. Give the editors `publish`, `unpublish`
and `discard` actions and they get Publish in the rail. The site's public pages read only the
published files, and turn drafts away.

### Motion

A site's animations are its own components. An entrance (something coming into view as the
reader scrolls to it) is declared with `defineMotion`: its name, a label, what it does, the
component, how edit mode replays it (`play`, Web Animations keyframes that match the
component) and what it does under reduced motion. It wraps blocks, so a post keeps what
animates in its MDX (`<Reveal>…</Reveal>`); register `still` too, so a block can keep still
(`<Still>`) whatever its post does. An entrance setting's choices are
`entranceChoice([fadeUp, iris])`: "none", then each by name. Edit mode shows them as tiles
that play, at every level the setting cascades to (the blog, a page or post, a section, a
block), and plays the choice on the page. The site renders a post with
`renderPost(source, config, { motion: entrance })` and a page's sections with
`renderPage(…, (node, section) => inEntrance(config, entranceOf(section), node))`.

Only real choices: an option marked `status: "planned"` anywhere (front matter, settings,
sections) makes `defineConfig` throw. A component can carry a `label` for how the editor
names it ("Picture and text").

### The design system

A site's colours, fonts and type styles are tokens in a W3C Design Tokens (DTCG) file beside
its CSS, each naming the CSS variable it is (`$extensions.galley.cssVar`), with a label
("Brand orange") and what it's for (`roles`). `fromDtcg(json)` reads them; pass them as the
config's `design: { tokens }`. A component or section setting that takes one is
`tokenChoice(tokens, { kind: "color", roles: ["accent"] })`: it stores the token's name, a
raw colour fails the check, and edit mode shows the choices as named swatches in a Style
group (type styles as samples in their real font). There's no colour picker and no hex
field anywhere. Blog settings › Design shows every token with how many posts use it
(`tokenUsage`) and a way to ask for a change; agents use `list_tokens`. Text blocks' styles
are drawn in the site's own type.

### The library

`galley index` (and edit mode, fresh each time) builds one list of everything a post or
page can use (`@blueprint-studio/galley/library`): the site's blocks, entrances, sections
and templates, and the pictures, video, Lottie animations (JSON) and files in its media
folder, named from the alt text posts give them. Each thing someone built carries the pull
request that added it (from the commit that added its file), and is shown as New for two
weeks, so the design agent's merged work appears without anyone registering it. Give the
editors a `siteLibrary` action (`buildLibrary(config, cwd)`) and the post editor's Add
becomes the Library: Blocks, Motion and Media in one view with one search, video and Lottie
playing while pointed at. Agents use `search_library`. Lottie is a base contract with a
starter (`galley add lottie`, which uses lottie-web's light player) that stays on its first
frame for readers who ask for less motion.

### Templates and design requests

A site's templates are `defineTemplate({ name, label, useWhen, for: "post", preview })`, the
preview a screenshot of a real post (`galley check` checks it's in `public/`), listed in
the config's `templates`; the site keeps one layout per name. `templateChoice(templates)`
is the template setting's choices. One that's wanted but not built is a design request
(`@blueprint-studio/galley/requests`): edit mode's "Ask for a new template" card writes one
to `.galley/requests/`, agents use `request_design`, and the design agent follows them with
`list_requests` and `update_request` (its pull request, then "shipped" with the name it
shipped as). Pass the editors `design={{ list, ask }}`; what's asked for is listed where
it's chosen with its status, and the person who asked is told when it's ready.

### Edit mode

`@blueprint-studio/galley/editor-ui` is edit mode for Next.js sites: the site's own post
page, editable in place. Wrap the post layout in `<EditSession>` (with the site's server
actions for saving, rendering components, the Blueprint Studio library and history) and
put `EditableText`, `EditableImage`, `EditableTerm`, `EditableAuthors` and `EditableBody`
where the title, cover, category, byline and body go. A page built from sections uses
`<PageEditor>`; a section renders its editable words with `SectionText` from
`@blueprint-studio/galley/section-text`. It needs `@tiptap/*` 3 alongside React 19.

Everything edit mode opens is one dock down the right edge: the rail of controls, and beside
it whatever is open (adding a block or section, drawn by the site itself; a selected block's
or section's settings; the picture chooser; details; comments; history; Blog settings). It
changes size to fit what it shows and slides the next view in from its button's side, like
a navigation menu. On the page, what you point at and select is drawn with construction
lines on its real box, and the page builds in from its skeleton when edit mode loads. Pass
`settings` to both editors. Sites whose header is taller or shorter than 92px
set `--gx-top` to where the dock starts.

### Version history

`recordSave(cwd, "posts/<slug>", { before, after, author, note? })` (from `@blueprint-studio/galley/editor`)
notes each save edit mode makes; a note ("Published") marks a moment of its own. A stretch of saves by one person within ten minutes is one
version, the state before the first edit is kept, and changes made outside edit mode show
up as their own version. `listVersions` and `readVersion` read them back for a history
panel. It lives in `.galley/history/`, which sites should git-ignore: the repo's own history
is the record that ships.

## For agents

`galley mcp` serves Galley's tools over stdio to agents working in the site's repo. Register
it in `.mcp.json` as `{"command": "./node_modules/.bin/galley", "args": ["mcp"]}`. Calling it
through `pnpm galley` would print pnpm's banner onto stdout and break the protocol. The tools:

- `list_posts`, `read_post`: posts with line numbers and a revision.
- `edit_post`: find-and-replace on exact text, refused if the post changed since it was read.
- `write_post`: create or replace a whole post.
- `check_post`: check MDX without saving.
- `list_components`: what each component is for, its props and an example.
- `import_media`: bring an https image (e.g. from Blueprint's Asset Generator) into the site.
- `list_sections`, `read_page`, `write_page`: pages built from sections, for sites that have
  them. A page is written whole, with the revision it was read at.
- `read_settings`, `write_settings`: the blog's settings, for sites that have them, written
  whole with the revision they were read at.
- `list_drafts`, `publish`, `unpublish_post`: every write is a draft until it's published,
  as in edit mode.
- `preview`: a post or the component gallery as screen-sized screenshots. Needs
  `playwright-core` and a `preview` block in the config, and works best against `pnpm dev`,
  where edits show up immediately.

Every save is checked first. A failed check returns line-numbered errors and nothing is
written. The same operations live in `@blueprint-studio/galley/ops` for other surfaces, over
any `PostStore`.

## For hosted tools

Blueprint's MCP works on a client's repo through GitHub, not the disk:

- `configFromManifest(manifest)` rebuilds a site's rules from its `.galley/manifest.json`.
  Posts are checked exactly as the site would check them, without running its code.
- `GitHubPostStore` (`@blueprint-studio/galley/github`) reads published posts from the base
  branch. Every write goes to that post's draft branch (`galley/<slug>`), with one open pull
  request, so a person merges to publish. Agents never write to the base branch.
- `githubAppTokens` signs the GitHub App's JWT and caches each installation's token.
- `prepareMedia` (`@blueprint-studio/galley/media`) downloads and optimises an image through the
  host's own `fetch`, so the host decides what may be fetched. `putFile` then adds it to the
  draft branch.

## Developing

```bash
pnpm install
pnpm test        # safety rules, Ghost import, manifest round trip, agent ops, GitHub drafts
pnpm typecheck   # engine and starters
pnpm build
```

CONTRIBUTING.md has the rules: the layers, the content format, adding other frameworks
(including non-React sites), edit mode's design and motion rules, and frame-checking
motion with `scripts/motion/`.

Sites install a packed release. `pnpm pack:vendor` writes the `.tgz` to
`../galley-releases/`. The site copies it into its `vendor/` folder and depends on
`file:./vendor/blueprint-studio-galley-<version>.tgz`. That way a client's site builds
without Blueprint's credentials.
