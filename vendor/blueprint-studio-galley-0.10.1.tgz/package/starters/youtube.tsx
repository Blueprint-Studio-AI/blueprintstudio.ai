import { defineComponent } from "@blueprint-studio/galley";
import { YouTube } from "@blueprint-studio/galley/contracts";
import { YouTubePlayer } from "./youtube-player";

// Starter from `galley add youtube`. Shows the video's thumbnail and loads YouTube's
// player only when the reader presses play: fast pages, and no YouTube cookies until then.

export const youtube = defineComponent({
  ...YouTube,
  examples: [{ title: "A video", props: { id: "aqz-KE-bpKQ", title: "Big Buck Bunny" } }],
  Component: (props) => (
    <figure className="galley-youtube">
      <YouTubePlayer {...props} />
    </figure>
  ),
});
