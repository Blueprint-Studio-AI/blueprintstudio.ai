import { defineComponent } from "@blueprint-studio/galley";
import { File } from "@blueprint-studio/galley/contracts";

// Starter from `galley add file`. This file is the site's now: restyle it freely.

export const file = defineComponent({
  ...File,
  examples: [{ title: "A PDF", props: { src: "/files/report.pdf", title: "The 2026 report", filename: "report.pdf", size: "2.4 MB" } }],
  Component: ({ src, title, caption, filename, size }) => (
    <a className="galley-file" href={src} download>
      <strong>{title}</strong>
      {caption ? <span>{caption}</span> : null}
      <small>{[filename, size].filter(Boolean).join(" · ")}</small>
    </a>
  ),
});
