import { defineComponent } from "@blueprint-studio/galley";
import { Video } from "@blueprint-studio/galley/contracts";

// Starter from `galley add video`. This file is the site's now: restyle it freely.

export const video = defineComponent({
  ...Video,
  examples: [
    {
      title: "A short clip",
      props: { src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4", width: 1280, height: 720 },
      children: "A caption under the video",
    },
  ],
  Component: ({ src, poster, width, height, loop, children }) => (
    <figure className="galley-video">
      <video src={src} poster={poster} width={width} height={height} loop={loop} controls playsInline preload="metadata" />
      {children ? <figcaption>{children}</figcaption> : null}
    </figure>
  ),
});
