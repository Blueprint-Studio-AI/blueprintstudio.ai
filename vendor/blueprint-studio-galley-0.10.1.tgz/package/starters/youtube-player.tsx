"use client";

import { useState } from "react";

// The interactive half of the YouTube component: a thumbnail and play button that swaps in
// the real player on click. Without JavaScript it's a link to the video on YouTube.

export function YouTubePlayer({ id, title, start }: { id: string; title?: string; start?: number }) {
  const [playing, setPlaying] = useState(false);
  const [thumb, setThumb] = useState(`https://i.ytimg.com/vi/${id}/maxresdefault.jpg`);
  const label = title ? `Play: ${title}` : "Play video";

  if (playing) {
    const query = new URLSearchParams({ autoplay: "1", rel: "0", ...(start ? { start: String(start) } : {}) });
    return (
      <iframe
        className="galley-youtube-frame"
        src={`https://www.youtube-nocookie.com/embed/${id}?${query}`}
        title={title ?? "YouTube video"}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        referrerPolicy="strict-origin-when-cross-origin"
        allowFullScreen
      />
    );
  }

  return (
    <a
      className="galley-youtube-poster"
      href={`https://www.youtube.com/watch?v=${id}${start ? `&t=${start}s` : ""}`}
      aria-label={label}
      onClick={(event) => {
        event.preventDefault();
        setPlaying(true);
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={thumb}
        alt=""
        loading="lazy"
        decoding="async"
        // Not every video has a full-resolution thumbnail; YouTube serves a 120px grey
        // placeholder instead of an error, so fall back on that too.
        onLoad={(e) => {
          if (e.currentTarget.naturalWidth <= 120) setThumb(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`);
        }}
        onError={() => setThumb(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`)}
      />
      <span className="galley-youtube-play" aria-hidden="true">
        <svg viewBox="0 0 68 48" width="68" height="48">
          <path d="M66.5 7.7c-.8-2.9-3-5.2-5.9-6C55.3 0 34 0 34 0S12.7 0 7.4 1.6c-2.9.8-5.2 3-5.9 6C0 13 0 24 0 24s0 11 1.5 16.3c.8 2.9 3 5.2 5.9 6C12.7 48 34 48 34 48s21.3 0 26.6-1.6c2.9-.8 5.2-3 5.9-6C68 35 68 24 68 24s0-11-1.5-16.3z" fill="#f00" />
          <path d="M45 24 27 14v20" fill="#fff" />
        </svg>
      </span>
      {title ? <span className="galley-youtube-title">{title}</span> : null}
    </a>
  );
}
