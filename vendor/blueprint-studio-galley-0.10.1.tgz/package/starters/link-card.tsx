import { defineComponent } from "@blueprint-studio/galley";
import { LinkCard } from "@blueprint-studio/galley/contracts";

// Starter from `galley add link-card`. This file is the site's now: restyle it freely.

export const linkCard = defineComponent({
  ...LinkCard,
  examples: [
    {
      title: "A link with a thumbnail",
      props: {
        url: "https://example.com/article",
        title: "An article worth reading",
        description: "One or two lines from the page itself.",
        publisher: "Example",
        thumbnail: "https://picsum.photos/id/1015/600/400",
      },
    },
  ],
  Component: ({ url, title, description, icon, thumbnail, author, publisher, children }) => (
    <figure className="galley-link-card">
      <a href={url}>
        <span className="galley-link-card-text">
          <strong>{title}</strong>
          {description ? <span>{description}</span> : null}
          <small>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {icon ? <img src={icon} alt="" width={16} height={16} loading="lazy" /> : null}
            {[author, publisher].filter(Boolean).join(" · ")}
          </small>
        </span>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {thumbnail ? <img className="galley-link-card-thumb" src={thumbnail} alt="" loading="lazy" /> : null}
      </a>
      {children ? <figcaption>{children}</figcaption> : null}
    </figure>
  ),
});
