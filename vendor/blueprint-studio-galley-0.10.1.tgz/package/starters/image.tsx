import { defineComponent } from "@blueprint-studio/galley";
import { Image } from "@blueprint-studio/galley/contracts";

// Starter from `galley add image`. This file is the site's now: restyle it freely.

export const image = defineComponent({
  ...Image,
  examples: [
    {
      title: "With a caption",
      props: { src: "https://picsum.photos/id/1018/1200/800", alt: "Mountains above a lake", width: 1200, height: 800 },
      children: "A caption with *emphasis* and a [link](https://example.com)",
    },
  ],
  Component: ({ src, alt, width, height, children }) => (
    <figure className="galley-image">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={alt} width={width} height={height} loading="lazy" decoding="async" />
      {children ? <figcaption>{children}</figcaption> : null}
    </figure>
  ),
});
