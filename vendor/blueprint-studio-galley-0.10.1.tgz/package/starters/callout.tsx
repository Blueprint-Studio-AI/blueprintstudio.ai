import { defineComponent } from "@blueprint-studio/galley";
import { Callout } from "@blueprint-studio/galley/contracts";

// Starter from `galley add callout`. This file is the site's now: restyle it freely.

export const callout = defineComponent({
  ...Callout,
  examples: [
    { title: "A tip", props: { tone: "tip", title: "Before you start" }, children: "Callouts hold paragraphs, lists and other components." },
  ],
  Component: ({ tone = "note", title, children }) => (
    <aside className="galley-callout" data-tone={tone}>
      {title ? <p className="galley-callout-title">{title}</p> : null}
      {children}
    </aside>
  ),
});
