import { defineComponent } from "@blueprint-studio/galley";
import { Tweet } from "@blueprint-studio/galley/contracts";
import { XEmbed } from "./x-embed";

// Starter from `galley add tweet`. Renders the post as a quote, which X's script then
// upgrades into its own embed. The script comes from this component, never from a post.

export const tweet = defineComponent({
  ...Tweet,
  examples: [
    {
      title: "A quoted post",
      props: { url: "https://x.com/jack/status/20", author: "jack (@jack)", date: "March 21, 2006" },
      children: "just setting up my twttr",
    },
  ],
  Component: ({ url, author, date, caption, children }) => (
    <figure className="galley-tweet">
      <XEmbed>
        <blockquote className="twitter-tweet">
          <p>{children}</p>
          &mdash; {author} <a href={url}>{date}</a>
        </blockquote>
      </XEmbed>
      {caption ? <figcaption>{caption}</figcaption> : null}
    </figure>
  ),
});
