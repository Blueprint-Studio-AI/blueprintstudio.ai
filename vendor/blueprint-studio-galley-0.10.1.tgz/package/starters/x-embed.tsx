"use client";

import { useEffect, useRef, type ReactNode } from "react";

// Loads X's widget script once and upgrades the quotes inside into X's embeds. Without
// JavaScript (or if X is blocked) the plain quote stays.

type Twttr = { widgets?: { load: (element?: Element) => void } };

const SCRIPT = "https://platform.twitter.com/widgets.js";

export function XEmbed({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const twttr = (window as unknown as { twttr?: Twttr }).twttr;
    if (twttr?.widgets) {
      twttr.widgets.load(ref.current ?? undefined);
      return;
    }
    if (document.querySelector(`script[src="${SCRIPT}"]`)) return;
    const script = document.createElement("script");
    script.src = SCRIPT;
    script.async = true;
    document.body.appendChild(script);
  }, []);
  return <div ref={ref}>{children}</div>;
}
